package org.example.currency_convertor;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.google.gson.Gson;

import javax.swing.text.html.ImageView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Controller {

    private String currencyOne, currencyTwo, apiKey;

    private ArrayList<String> currencyList;

    @FXML
    private ImageView logo;

    @FXML
    private TextField enterAmountField;

    @FXML
    private ComboBox<String> currencyOneBox, currencyTwoBox;

    @FXML
    private Label resultLable;

    public void initialize() {
        getApiKey();

        loadLogo();

        try{
            //try to retrive list of currencies
            currencyList= LoadCurrencyList();

            //store the list in the combo box
            ObservableList<String> options = FXCollections.observableArrayList(currencyList);
            currencyOneBox.setItems(options);
            currencyTwoBox.setItems(options);

        }catch (Exception e){
            System.out.println("Error: failed to load currencies");
        }
    }

    public   void setCurrencyOne(){ currencyOne = currencyOneBox.getValue(); }
    public void setCurrencyTwo(){ currencyTwo = currencyTwoBox.getValue(); }
    private void getApiKey() {
        BufferedReader reader=null;
        try {
            String filePath = getClass().getResource("src/main/resources/org/example/currency_convertor/ApiKey.txt").getPath()
                    .replace("%20", " ");
            reader = new BufferedReader(new FileReader(filePath));
            //Store API key
            apiKey = reader.readLine();

        }catch (IOException e) {
            System.out.println("Error:  " + e);
        }finally {
            // colse bufferedReader object to avoid memory leak
            try {
                if (reader != null) {
                    reader.close();
                }
                catch(IOException e){
                    System.out.println("Error:  " + e);
                }

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void loadLogo() {
    String iconPath = getClass().getResource("src/main/resources/org/example/currency_convertor/dollar.png").getPath()
            .replace("%20", " ");
    logo.setImage(new Image(new File(iconPath).getAbsolutePath()));
    }

    private ArrayList<String> loadCurrencyList()  throws IOException {
        //retrive list of currencies through API
        OkHttpClient client = new OkHttpClient().newBuilder().build();

        Request request = new Request.Builder()
                .url("https://api.apilayer.com/currency_data/live?source=source&currencies=currencies")
                .addHeader("apikey", apiKey)
                .method("GET", null)
            .build();
    Response response = client.newCall(request).execute();

    Gson gson = new Gson();
    JsonElement jsonElement = gson.fromJson(response.body().charStream(), JsonElement.class);
    JsonObject jsonObject = jsonElement.getAsJsonObject();

    ArrayList<String> currencyList = new ArrayList<>();
    for (String currency : jsonObject.getAsJsonObject("currencies").keySet()) {
        currencyList.add(currency);
    }
    return currencyList;
    }
    public void convertCurrency() throws IOException {
    if(enterAmountField.getText().equals("") || enterAmountField.getText()==null) return;
    if(currencyOne==null || currencyTwo==null) return;

    float conversation = getConversionRate();

    //calculate conversion
    float amount = Float.parseFloat(enterAmountField.getText());
    float ConversionResult = amount * conversation;
    resultLable.setText(String.valueOf(result));

    //dispaly result
    resultLable.setText(String.format("%.2f", ConversionResult) + " " + currencyTwo);


    }

    private float getConversionRate() throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();

        Request request = new Request.Builder()
                .url("https://api.apilayer.com/currency_data/live?source=" + currencyOne + "&currencies=" + currencyTwo)
                .addHeader("apikey", apiKey)
                .method("GET", null)
        .build();
       Response response = client.newCall(request).execute();

       Gson gson = new Gson();
       JsonElement jsonElement = gson.fromJson(response.body().charStream(), JsonElement.class);
       JsonObject jsonObject = jsonElement.getAsJsonObject();
       float conversionRate = jsonObject.getAsJsonObject("conversion_rates").get(currencyTwo).getAsFloat();
       return conversionRate;

    }
}